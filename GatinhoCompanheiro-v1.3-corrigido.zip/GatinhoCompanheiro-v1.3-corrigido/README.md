# 🐱 Gatinho Companheiro — v1.1

Primeiro protótipo Android do Gatinho Companheiro, revisado para a compilação atual do projeto.

## Incluído nesta versão

- Tela inicial com gatinho e frases acolhedoras.
- Registro simples de humor.
- Diário emocional salvo no aparelho.
- Lembretes com data e horário.
- Notificações de lembretes.
- Reagendamento de lembretes após reiniciar o aparelho.
- Widget para a tela inicial com frases variadas.
- Área de ajuda.
- Projeto preparado para compilação pelo GitHub Actions.

## Próximas versões

- Arte e animações finais do gatinho.
- Mais estados e interações no widget.
- Contas de usuário e mensagens entre pessoas.
- Envio de carinho por meio do gatinho.
- Privacidade, bloqueio e denúncia para a parte social.

## Compilação

O workflow `.github/workflows/android.yml` compila um APK de teste (`debug`) quando houver push na branch `main` ou quando a ação for iniciada manualmente.
