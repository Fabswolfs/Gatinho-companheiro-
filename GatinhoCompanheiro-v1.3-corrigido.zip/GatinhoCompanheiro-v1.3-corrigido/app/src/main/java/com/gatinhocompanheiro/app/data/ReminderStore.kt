package com.gatinhocompanheiro.app.data

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object ReminderStore {
    private const val PREFS = "cat_prefs"
    private const val KEY = "reminders"
    private val format = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault())

    fun load(context: Context): List<Reminder> = runCatching {
        val raw = context.getSharedPreferences(PREFS, 0).getString(KEY, "[]") ?: "[]"
        val arr = JSONArray(raw)
        (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            Reminder(
                id = o.optString("id").ifBlank { java.util.UUID.randomUUID().toString() },
                title = o.optString("title", "Lembrete"),
                date = o.optString("date"),
                time = o.optString("time")
            )
        }
    }.getOrDefault(emptyList())

    fun save(context: Context, list: List<Reminder>) {
        val arr = JSONArray()
        list.forEach { r ->
            arr.put(JSONObject().apply {
                put("id", r.id)
                put("title", r.title)
                put("date", r.date)
                put("time", r.time)
            })
        }
        context.getSharedPreferences(PREFS, 0).edit().putString(KEY, arr.toString()).apply()
    }

    fun schedule(context: Context, reminder: Reminder) {
        val whenMillis = runCatching { format.parse("${reminder.date} ${reminder.time}")?.time ?: 0L }.getOrDefault(0L)
        if (whenMillis <= System.currentTimeMillis()) return

        val intent = Intent(context, ReminderReceiver::class.java)
            .putExtra("title", reminder.title)
            .putExtra("id", reminder.id)
        val requestCode = reminder.id.hashCode()
        val pending = PendingIntent.getBroadcast(
            context,
            requestCode,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val alarm = context.getSystemService(AlarmManager::class.java)
        alarm.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, whenMillis, pending)
    }

    fun cancel(context: Context, reminder: Reminder) {
        val intent = Intent(context, ReminderReceiver::class.java)
        val pending = PendingIntent.getBroadcast(
            context,
            reminder.id.hashCode(),
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        context.getSystemService(AlarmManager::class.java).cancel(pending)
    }

    fun scheduleFuture(context: Context) {
        load(context).forEach { schedule(context, it) }
    }
}
