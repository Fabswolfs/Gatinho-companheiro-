package com.gatinhocompanheiro.app.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

object DiaryStore {
    private const val PREFS = "cat_prefs"
    private const val KEY = "diary"

    fun load(context: Context): List<DiaryEntry> = runCatching {
        val raw = context.getSharedPreferences(PREFS, 0).getString(KEY, "[]") ?: "[]"
        val arr = JSONArray(raw)
        (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            DiaryEntry(
                id = o.optString("id"),
                mood = o.optString("mood", "Bem"),
                text = o.optString("text"),
                date = o.optString("date")
            )
        }.reversed()
    }.getOrDefault(emptyList())

    fun add(context: Context, entry: DiaryEntry) {
        val list = load(context).reversed().toMutableList()
        list.add(entry)
        val arr = JSONArray()
        list.forEach { e ->
            arr.put(JSONObject().apply {
                put("id", e.id)
                put("mood", e.mood)
                put("text", e.text)
                put("date", e.date)
            })
        }
        context.getSharedPreferences(PREFS, 0).edit().putString(KEY, arr.toString()).apply()
    }
}
