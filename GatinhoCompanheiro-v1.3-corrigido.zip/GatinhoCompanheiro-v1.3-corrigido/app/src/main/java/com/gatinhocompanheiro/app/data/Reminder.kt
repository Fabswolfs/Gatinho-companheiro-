package com.gatinhocompanheiro.app.data

data class Reminder(
    val id: String,
    val title: String,
    val date: String,
    val time: String
)
