package com.gatinhocompanheiro.app

import android.Manifest
import android.app.DatePickerDialog
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.TimePickerDialog
import android.content.Context
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.gatinhocompanheiro.app.data.DiaryEntry
import com.gatinhocompanheiro.app.data.DiaryStore
import com.gatinhocompanheiro.app.data.Reminder
import com.gatinhocompanheiro.app.data.ReminderStore
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.UUID

private val Cream = Color(0xFFFFF8ED)
private val Green = Color(0xFF356B5B)
private val Lavender = Color(0xFFE9E1F5)
private val Peach = Color(0xFFFFE1D2)

class MainActivity : ComponentActivity() {
    private val notificationPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) {}

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        createNotificationChannel(this)
        if (Build.VERSION.SDK_INT >= 33) notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        ReminderStore.scheduleFuture(this)
        setContent { CatApp(this) }
    }
}

@Composable
fun CatApp(context: Context) {
    var screen by remember { mutableStateOf("home") }
    var mood by remember { mutableStateOf("Mais ou menos") }
    var catMessage by remember { mutableStateOf("Respira. Um passo de cada vez. 🐾") }
    val messages = remember {
        listOf(
            "Vai no seu ritmo. 🐾",
            "Hoje não precisa ser perfeito.",
            "Respira. Um passo de cada vez.",
            "Que bom que você está aqui. 🐱",
            "Faça uma coisa de cada vez.",
            "Você merece um pouco de descanso.",
            "Pequenos passos também contam. 🌿"
        )
    }
    val reminders = remember { mutableStateListOf<Reminder>().apply { addAll(ReminderStore.load(context)) } }

    MaterialTheme(colorScheme = lightColorScheme(primary = Green, background = Cream)) {
        Surface(Modifier.fillMaxSize(), color = Cream) {
            when (screen) {
                "reminders" -> ReminderScreen(context, reminders) { screen = "home" }
                "diary" -> DiaryScreen(context) { screen = "home" }
                "help" -> HelpScreen { screen = "home" }
                else -> HomeScreen(
                    message = catMessage,
                    mood = mood,
                    onMood = { mood = it },
                    onNewMessage = { catMessage = messages.random() },
                    onReminders = { screen = "reminders" },
                    onDiary = { screen = "diary" },
                    onHelp = { screen = "help" }
                )
            }
        }
    }
}

@Composable
fun HomeScreen(
    message: String,
    mood: String,
    onMood: (String) -> Unit,
    onNewMessage: () -> Unit,
    onReminders: () -> Unit,
    onDiary: () -> Unit,
    onHelp: () -> Unit
) {
    Column(
        Modifier.fillMaxSize().padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(Modifier.height(20.dp))
        Text("Gatinho Companheiro 🐾", fontSize = 28.sp, fontWeight = FontWeight.Bold, color = Green)
        Text("Um pequeno amigo para os momentos do dia.", color = Color.DarkGray)
        Spacer(Modifier.height(18.dp))
        CatCard(message, onNewMessage)
        Spacer(Modifier.height(18.dp))
        Text("Como você está se sentindo hoje?", fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
        listOf("Bem", "Mais ou menos", "Triste", "Muito mal").forEach { item ->
            MoodButton(item, item == mood) { onMood(item) }
        }
        Spacer(Modifier.height(8.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            SmallAction("🔔", "Lembretes", onReminders, Modifier.weight(1f))
            SmallAction("📔", "Diário", onDiary, Modifier.weight(1f))
            SmallAction("🆘", "Ajuda", onHelp, Modifier.weight(1f))
        }
    }
}

@Composable
fun CatCard(message: String, onClick: () -> Unit) {
    Card(
        Modifier.fillMaxWidth().height(230.dp).clickable { onClick() },
        shape = RoundedCornerShape(28.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFFE5F0EA))
    ) {
        Column(
            Modifier.fillMaxSize().padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text("🐱", fontSize = 72.sp)
            Text("🐾", fontSize = 26.sp)
            Text(message, fontSize = 20.sp, fontWeight = FontWeight.Medium, color = Color(0xFF263B35))
            Text("Toque no gatinho para uma nova frase", fontSize = 12.sp, color = Color.Gray)
        }
    }
}

@Composable
fun MoodButton(label: String, selected: Boolean, onClick: () -> Unit) {
    val bg = if (selected) Lavender else Color.White
    Row(
        Modifier.fillMaxWidth().padding(vertical = 3.dp)
            .clip(RoundedCornerShape(16.dp)).background(bg)
            .clickable { onClick() }.padding(14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            when (label) {
                "Bem" -> "😊"
                "Mais ou menos" -> "😐"
                "Triste" -> "😔"
                else -> "😞"
            },
            fontSize = 22.sp
        )
        Spacer(Modifier.width(12.dp))
        Text(label, fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal)
    }
}

@Composable
fun SmallAction(icon: String, title: String, onClick: () -> Unit, modifier: Modifier) {
    Card(
        modifier.clickable { onClick() },
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White)
    ) {
        Column(Modifier.padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(icon, fontSize = 24.sp)
            Text(title, fontSize = 12.sp)
        }
    }
}

@Composable
fun ReminderScreen(context: Context, reminders: MutableList<Reminder>, onBack: () -> Unit) {
    var title by remember { mutableStateOf("") }
    var date by remember { mutableStateOf("") }
    var time by remember { mutableStateOf("") }
    var error by remember { mutableStateOf("") }

    Column(Modifier.fillMaxSize().padding(20.dp)) {
        TextButton(onClick = onBack) { Text("← Voltar") }
        Text("Lembretes 🐾", fontSize = 28.sp, fontWeight = FontWeight.Bold, color = Green)
        Text("O gatinho lembra o que importa para você.", color = Color.Gray)
        Spacer(Modifier.height(12.dp))

        OutlinedTextField(title, { title = it }, Modifier.fillMaxWidth(), label = { Text("O que lembrar?") }, singleLine = true)
        Spacer(Modifier.height(8.dp))
        OutlinedButton(onClick = {
            val now = Calendar.getInstance()
            DatePickerDialog(context, { _, y, m, d ->
                date = String.format(Locale.getDefault(), "%02d/%02d/%04d", d, m + 1, y)
            }, now.get(Calendar.YEAR), now.get(Calendar.MONTH), now.get(Calendar.DAY_OF_MONTH)).show()
        }, Modifier.fillMaxWidth()) { Text(if (date.isBlank()) "Escolher data" else "Data: $date") }
        Spacer(Modifier.height(8.dp))
        OutlinedButton(onClick = {
            val now = Calendar.getInstance()
            TimePickerDialog(context, { _, h, min ->
                time = String.format(Locale.getDefault(), "%02d:%02d", h, min)
            }, now.get(Calendar.HOUR_OF_DAY), now.get(Calendar.MINUTE), true).show()
        }, Modifier.fillMaxWidth()) { Text(if (time.isBlank()) "Escolher horário" else "Horário: $time") }

        if (error.isNotBlank()) {
            Spacer(Modifier.height(6.dp))
            Text(error, color = MaterialTheme.colorScheme.error)
        }

        Spacer(Modifier.height(8.dp))
        Button(onClick = {
            val parsed = runCatching {
                SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault()).apply { isLenient = false }
                    .parse("$date $time")?.time ?: 0L
            }.getOrDefault(0L)
            error = when {
                title.isBlank() -> "Digite o que você quer lembrar."
                date.isBlank() || time.isBlank() -> "Escolha a data e o horário."
                parsed <= System.currentTimeMillis() -> "Escolha um horário futuro."
                else -> ""
            }
            if (error.isBlank()) {
                val reminder = Reminder(UUID.randomUUID().toString(), title.trim(), date, time)
                reminders.add(reminder)
                ReminderStore.save(context, reminders)
                ReminderStore.schedule(context, reminder)
                title = ""; date = ""; time = ""
            }
        }, modifier = Modifier.fillMaxWidth()) { Text("Salvar lembrete") }

        Spacer(Modifier.height(16.dp))
        if (reminders.isEmpty()) {
            Text("Nenhum lembrete ainda. 🌿", color = Color.Gray)
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(reminders, key = { it.id }) { r ->
                    Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                        Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text("🔔", fontSize = 24.sp)
                            Spacer(Modifier.width(10.dp))
                            Column(Modifier.weight(1f)) {
                                Text(r.title, fontWeight = FontWeight.Bold)
                                Text("${r.date} • ${r.time}", color = Color.Gray)
                            }
                            TextButton(onClick = {
                                ReminderStore.cancel(context, r)
                                reminders.remove(r)
                                ReminderStore.save(context, reminders)
                            }) { Text("Excluir") }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun DiaryScreen(context: Context, onBack: () -> Unit) {
    var text by remember { mutableStateOf("") }
    var selected by remember { mutableStateOf("Bem") }
    var saved by remember { mutableStateOf(false) }
    var entries by remember { mutableStateOf(DiaryStore.load(context)) }

    Column(Modifier.fillMaxSize().padding(20.dp)) {
        TextButton(onClick = onBack) { Text("← Voltar") }
        Text("Diário emocional 📔", fontSize = 28.sp, fontWeight = FontWeight.Bold, color = Green)
        Spacer(Modifier.height(12.dp))
        Text("Como foi seu dia?", fontSize = 18.sp)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
            listOf("Bem", "Ok", "Triste", "Muito mal").forEach { mood ->
                Text(
                    when (mood) { "Bem" -> "😊 $mood"; "Ok" -> "😐 $mood"; "Triste" -> "😔 $mood"; else -> "😞 $mood" },
                    Modifier.clickable { selected = mood }.padding(8.dp),
                    fontWeight = if (selected == mood) FontWeight.Bold else FontWeight.Normal
                )
            }
        }
        OutlinedTextField(text, { if (it.length <= 500) text = it }, Modifier.fillMaxWidth().height(180.dp), label = { Text("Quer escrever alguma coisa?") })
        Spacer(Modifier.height(12.dp))
        Button(onClick = {
            DiaryStore.add(context, DiaryEntry(UUID.randomUUID().toString(), selected, text.trim(), SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault()).format(Date())))
            entries = DiaryStore.load(context)
            text = ""
            saved = true
        }, Modifier.fillMaxWidth(), enabled = text.isNotBlank()) { Text("Salvar") }
        if (saved) Text("Salvo com carinho. 🐾", color = Green)
        Spacer(Modifier.height(14.dp))
        Text("Registros recentes", fontWeight = FontWeight.Bold)
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(entries.take(10), key = { it.id }) { entry ->
                Card(colors = CardDefaults.cardColors(containerColor = Color.White)) {
                    Column(Modifier.fillMaxWidth().padding(12.dp)) {
                        Text("${entry.mood} • ${entry.date}", fontWeight = FontWeight.Bold)
                        if (entry.text.isNotBlank()) Text(entry.text, color = Color.DarkGray)
                    }
                }
            }
        }
    }
}

@Composable
fun HelpScreen(onBack: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(20.dp)) {
        TextButton(onClick = onBack) { Text("← Voltar") }
        Text("Precisa de ajuda? 🆘", fontSize = 28.sp, fontWeight = FontWeight.Bold, color = Green)
        Spacer(Modifier.height(12.dp))
        Text("O Gatinho Companheiro é um apoio e não substitui psicólogos, médicos ou serviços de emergência.", fontSize = 16.sp)
        Spacer(Modifier.height(12.dp))
        Card(colors = CardDefaults.cardColors(containerColor = Peach)) {
            Column(Modifier.padding(18.dp)) {
                Text("Se houver risco imediato", fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(6.dp))
                Text("Procure uma pessoa de confiança ou os serviços de emergência da sua região.")
            }
        }
        Spacer(Modifier.height(12.dp))
        Text("No Brasil, o CVV atende pelo 188, gratuitamente, para apoio emocional.", color = Color.DarkGray)
    }
}

fun createNotificationChannel(context: Context) {
    if (Build.VERSION.SDK_INT >= 26) {
        val channel = NotificationChannel("reminders", "Lembretes do gatinho", NotificationManager.IMPORTANCE_DEFAULT).apply {
            description = "Lembretes criados pelo Gatinho Companheiro"
        }
        context.getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
    }
}
