package com.gatinhocompanheiro.app.data

data class DiaryEntry(
    val id: String,
    val mood: String,
    val text: String,
    val date: String
)
