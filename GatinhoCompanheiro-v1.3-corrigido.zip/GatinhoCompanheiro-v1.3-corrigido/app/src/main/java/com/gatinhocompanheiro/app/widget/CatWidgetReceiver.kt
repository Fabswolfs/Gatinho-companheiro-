package com.gatinhocompanheiro.app.widget

import android.content.Context
import androidx.glance.GlanceId
import androidx.glance.GlanceModifier
import androidx.glance.Image
import androidx.glance.ImageProvider
import androidx.glance.action.actionStartActivity
import androidx.glance.action.clickable
import androidx.glance.appwidget.GlanceAppWidget
import androidx.glance.appwidget.GlanceAppWidgetReceiver
import androidx.glance.appwidget.provideContent
import androidx.glance.background
import androidx.glance.layout.Alignment
import androidx.glance.layout.Column
import androidx.glance.layout.Spacer
import androidx.glance.layout.fillMaxSize
import androidx.glance.layout.height
import androidx.glance.layout.padding
import androidx.glance.text.Text
import androidx.glance.text.TextStyle
import androidx.glance.unit.ColorProvider
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.graphics.Color
import com.gatinhocompanheiro.app.MainActivity
import com.gatinhocompanheiro.app.R

class CatWidgetReceiver : GlanceAppWidgetReceiver() {
    override val glanceAppWidget: GlanceAppWidget = CatWidget()
}

class CatWidget : GlanceAppWidget() {
    private val messages = listOf(
        "Vai no seu ritmo. 🐾",
        "Hoje não precisa ser perfeito.",
        "Respira. Um passo de cada vez.",
        "Que bom que você está aqui. 🐱",
        "Faça uma coisa de cada vez."
    )

    override suspend fun provideGlance(context: Context, id: GlanceId) = provideContent {
        val message = messages.random()
        Column(
            modifier = GlanceModifier.fillMaxSize()
                .background(ColorProvider(Color(0xFFFFF8ED)))
                .padding(12.dp)
                .clickable(actionStartActivity<MainActivity>()),
            verticalAlignment = Alignment.CenterVertically,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Image(
                provider = ImageProvider(R.drawable.cat_widget),
                contentDescription = "Gatinho Companheiro"
            )
            Spacer(GlanceModifier.height(4.dp))
            Text(
                message,
                style = TextStyle(
                    fontSize = 14.sp,
                    color = ColorProvider(Color(0xFF263B35))
                )
            )
        }
    }
}
